// Function to convert USD to CAD
function protsan_275_f1() {
    var amount_275 = parseFloat(document.getElementById('USD').value);

    if (isNaN(amount_275) || amount_275 <= 0 || amount_275 === null || amount_275 === "") {
        alert('Enter a valid amount.');
        return;
    }

    // Conversion rate of usd to cad
    var exchange_rate_275 = 1.27;

    // Calculate and display converted amount
    var converted_275 = (amount_275 * exchange_rate_275).toFixed(3);

    document.getElementById('CAD').value = converted_275;
    document.getElementById('CAD').focus();
}

// Function to convert CAD to USD
function protsan_275_f2() {
    var amount_275 = parseFloat(document.getElementById('CAD').value);

    if (isNaN(amount_275) || amount_275 <= 0 || amount_275 === null || amount_275 === "") {
        alert('Enter a valid amount.');
        return;
    }

    // conversion rate of cad to usd
    var exchange_rate_275 = 0.79;

    // Calculate and display converted amount
    var converted_275 = (amount_275 * exchange_rate_275).toFixed(3);

    document.getElementById('USD').value = converted_275;
    document.getElementById('USD').focus();
}

// Function to display current time
setInterval(function protsan275() {
    var date275 = new Date();
    var hours_275 = date275.getHours();
    var minutes_275 = date275.getMinutes();
    var seconds_275 = date275.getSeconds();

    // Clock format
    var formattedTime = hours_275 + ':' + minutes_275 + ':' + seconds_275;

    document.getElementById('clock').innerText = "Time is: " + formattedTime;
}, 1000);
